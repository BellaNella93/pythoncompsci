coke = 3
steak = 10

price_1 = 2.50
price_2 = 1.50

print(coke * price_1)
print(steak * price_2)
