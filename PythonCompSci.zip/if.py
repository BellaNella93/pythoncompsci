# movies I saw in 2018
movie_count = 10

if movie_count > 4:
	print("You Watched a Lot of Movies!")
else:
	print("You Watched a Few...")