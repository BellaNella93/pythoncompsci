# movies I saw in 2018
movie_count = [3,4,5,7,10]

for i in range(0,len(movie_count)):
	if movie_count [i]> 4: #used forloop by tabbing over 
		print("You Watched a Lot of Movies!")
	else:
		print("You Watched a Few...")