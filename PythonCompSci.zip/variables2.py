coke = 3
steak = 15

price_1 = 2.50
price_2 = 1.50

print("coke:" , coke * price_1)
print("steak:", steak * price_2)
print("coke: $" + str(coke * price_1))
print("steak: $" + str(steak * price_2))

total = (coke + price_1) + (steak * price_2)
tip= 0.18

total_with_tip_= total * tip + total
print("total with tip: $",total_with_tip_)

"""todo:
1.
2.
3.
"""
#math operators: */ + - %,//