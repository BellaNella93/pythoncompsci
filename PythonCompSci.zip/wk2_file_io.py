filename = "nella\practice.txt"
file = open (filename,"w")
file.write("My name is Ornella.")
file.close()
# for line in file
# print line 

#if there is a file the system will use it and if there is not a file it will create it.
